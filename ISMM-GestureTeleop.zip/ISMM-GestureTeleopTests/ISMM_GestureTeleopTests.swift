//
//  ISMM_GestureTeleopTests.swift
//  ISMM-GestureTeleopTests
//
//  Created by Andrew  on 21/05/2025.
//

import Testing
@testable import ISMM_GestureTeleop

struct ISMM_GestureTeleopTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
